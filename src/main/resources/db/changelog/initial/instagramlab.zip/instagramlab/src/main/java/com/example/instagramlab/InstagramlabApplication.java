package com.example.instagramlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstagramlabApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstagramlabApplication.class, args);
	}

}
