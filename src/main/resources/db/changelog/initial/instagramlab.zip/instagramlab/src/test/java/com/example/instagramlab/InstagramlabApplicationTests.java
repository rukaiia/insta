package com.example.instagramlab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstagramlabApplicationTests {

	@Test
	void contextLoads() {
	}

}
