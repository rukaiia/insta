
package com.example.instagramlab.repository;

import com.example.instagramlab.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
