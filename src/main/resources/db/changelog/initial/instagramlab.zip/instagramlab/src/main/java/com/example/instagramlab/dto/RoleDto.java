package com.example.instagramlab.dto;

public class RoleDto {
}
